#include <iostream>

#include <presets/concepts/bwb/weightmodels/bradleybwb.h>
#include <core/modules/mission.h>


#include <components/turbofan.h>
#include <core/global/requirements.h>
#include <core/global/atmosphere.h>
#include <core/modules/aerodynamics.h>
#include <core/modules/weight.h>

#include <presets/concepts/bwb/aeromodels/transonicbwb.h>

using namespace std;

/* utility functions */
inline double FF_liftsur(double, double, double, double); // form factor for lift surfaces
inline double Re_(double, double, double, double); // Reynolds number (cutoff)
inline double Cf_(double, double); // skin friction coefficient


#include <cmath>
#define pi (2.0 * acos(0.0))

// core headers
#include <core/global/requirements.h>
#include <core/global/atmosphere.h>
// bwb headers
#include <presets/concepts/bwb/bwbtype.h>
#include <presets/concepts/bwb/aeromodels/transonicbwb.h>
#include <presets/concepts/bwb/weightmodels/bradleybwb.h>
// common headers
#include <presets/missionmodels/basicjet.h>
#include <presets/performancemodels/basicperformance.h>
#include <iostream>
#include <cmath>
#define fts_to_kt 0.5924838

#include <fstream>
#include <string>
#include <stdio.h>
using namespace StardustPlus;

string fname_bwb = "BWB224U";
string type = "";







Requirements *B767_200ER() {  //requirements.cpp l.15 requirements.h l.13 decide specific requirements
    Atmosphere *atm = new Atmosphere;
    map<string, double> reqs;
    reqs["h_cr"] = 35000.0;
    reqs["h_ceil"] = 41000.0;
    reqs["R_cr"] = 6545.0;
    reqs["V_cr"] = atm->a(reqs["h_cr"]) * 0.80 * fts_to_kt;
    reqs["M_cr"] = 0.80;
    reqs["h_ltr"] = 1500;
    reqs["E_ltr"] = 0.75;
    reqs["M_ltr"] = 0.4;
    reqs["h_div"] = 10000.0;
    reqs["R_div"] = 200.0;
    reqs["M_div"] = 0.75;
    reqs["V_div"] = atm->a(reqs["h_div"]) * 0.75 * fts_to_kt;
    reqs["V_d"] = 400.0 / fts_to_kt;
    reqs["N_crew"] = 10;
    reqs["N_pax"] = 224;
    reqs["W_PL"] = 220.0 * reqs["N_pax"];
    reqs["WL_max"] = 0.759;
    return new Requirements(reqs);
}
void BWBType::init() {
    moduleMap["Aerodynamics"] = new TransonicBWB(this);
    moduleMap["Mission"] = new BasicJet(this);
    moduleMap["Weight"] = new BradleyBWB(this);
    static_cast<BradleyBWB *>(moduleMap["Weight"])->init();
    moduleMap["Performance"] = new BasicPerformance(this);
}

void BWBType::saveData(string filename) { }
void BWBType::saveData(string filename, bool append) { }



int main() {
    string s;

    

    ofstream fout(fname_bwb + ".csv");
    if(!fout.is_open()) {  //開けなかったらエラーメッセージを吐く
        cout << "file can't be opened!" << endl;

        return 1;
    }

    ifstream fin("VAR" + fname_bwb);
    if(!fin.is_open()) {  //開けなかったらエラーメッセージを吐く
    cout << "file can't be opened!" << endl;
        return 1;
    }




    fout << fname_bwb << ",";
    fout << "L/D,";
    fout << "1/(L/D),";
    fout << "W_TO,";
    fout << "W_F,";
    fout << "W_OE,";
    fout << "W_E,";
    fout << "weightfraction,";
    fout << "Cargotype,";
    fout << "Bay,";
    fout << "CargoRow,";
    fout << "T_TO,";
    fout << "S_all,";
    fout << "S_vessel,";
    fout << "AR_all,";
    fout << "b_wing,";
    fout << "l_midbody,";
    fout << "h_root_midbody,";
    fout << "tc_ave_midbody,";
    
    fout << "Cabin Filling Rate,";
    fout << "Cargo Filling Rate,";



    fout << "l_midbody,";
    fout << "l_vessel,";
    fout << "l_cabin,";
    fout << "w_bay,";
    fout << "n_bay,";
    fout << "b_cabin,";
    fout << "b_midbody,";
    fout << "taper_midbody,";
    fout << "l_sweep_midbody,"; 
    fout << "h_root_midbody,"; 
    fout << "h_tip_midbody,";
    fout << "n_undercargo,";
    fout << "n_sidecargo,";
    fout << "n_rearcargo,";


    fout << "S_wing,";
    fout << "b_wing,";
    fout << "taper_wing,"; 
    fout << "sweep_wing,";
    fout << "tc_root_wing,";
    fout << "tc_tip_wing,";
    fout << "xc_m((x/c)max),"; 
    fout << "midbody_mac,";
    fout << "midbody_y_mac,";
    fout << "midbody_x_ac,";
    fout << "outer_mac,";
    fout << "outer_y_mac,";
    fout << "outer_x_ac,";
    fout << "all_mac,";
    fout << "all_y_mac,";
    fout << "all_x_ac,";
    fout << "CG_BW,";
    fout << "CG_FW,";



    fout << "N_engine,"; 
    fout << "W_engine,";
    fout << "T_to,";
    fout << "BPR,"; 
    fout << "d_engine,"; 
    fout << "l_engine,";

    fout << "CD0,";
    fout << "K,";
    fout << "CL,"; 
    fout << "CD_fric,";
    fout << "CD_wave,";

    fout << "TOFL,";
    fout << "LFL,";
    fout << "SSC,";
    fout << "ICAC,";


    fout << "l,";
    fout << "l_sweep_midbody,";
    fout << "b_midbody,";
    fout << "l_tip,";
    fout << "l_sweep_wing,";
    fout << "b,";
    fout << "c_tip,";

    fout << "h,";

    fout << "h_tip" << endl;



 






    int i = 0;
    double WF = 1e10;//燃料重量
    double WFmin = 0;//fuel minimum airplane
    string number;
    while(!fin.eof() && i < 300) {   //i番目の個体についてのhrmファイルを作る
        i += 1;
        fout << i << ",";
        number = to_string(i);//int型をstring型に変換

        double T_to;//double型変数の宣言
        double S;//Wingの面積
        double AR;//Wingスパン
        double sweep;
        double l;
        double taper_wing;//主翼テーパー比
        double n_bay_double;
        double n_cargorow_double;
        double cargotype_double;
        double h_margin;
        string verticalline;
        double LbyD;
        double weight;

        fin >> T_to;//ファイルの数値を格納
        fin >> S;
        fin >> AR;
        fin >> sweep;
        fin >> l;
        fin >> taper_wing;
        fin >> n_bay_double;
        int n_bay = (int)n_bay_double;
        fin >> n_cargorow_double;
        fin >> cargotype_double;
        int cargotype = (int)cargotype_double;
        fin >> h_margin;
        fin >> verticalline;//縦棒(いらない)
        fin >> LbyD;//L/D(いらない)
        fin >> weight;//重量(いらない)

        //if(制約違反がある)
        //continue
        //を入れたい



        BWBType *test = new BWBType("B767Type");
        auto eng = static_cast<Turbofan *>(test->getComponent("Engine"));
        double ScaleFactor = T_to / test->getComponent("Engine" )->getValue("T_to");//Scale Factor
        eng->scale(ScaleFactor);//エンジンとナセルの値を書き換え
        test->getComponent("Wing"   )->setValue("S"    ,S);   //主翼面積
        test->getComponent("Wing"   )->setValue("AR"   ,AR);   //主翼スパン
        test->getComponent("Wing"   )->setValue("sweep",sweep);   //主翼後退角
        test->getComponent("MidBody")->setValue("l"    ,l);   //胴体翼長さ
        test->getComponent("Wing"   )->setValue("taper",taper_wing);   //主翼テーパー比
        test->getComponent("MidBody")->setValue("n_bay",n_bay); //Bayの数を設定

        string name;
        string row;
        double n_cargorow;
        if (type == "DD") {
            if (cargotype == 0) {
                test->getComponent("MidBody")->setValue("h_root", 23.0 + h_margin);
                test->getComponent("MidBody")->setValue("h_mid", 23.0 + h_margin);
                test->getComponent("MidBody")->setValue("h_tip", 16.5 + h_margin);
                n_cargorow = ((int)(n_cargorow_double/2.0))*2;
                test->getComponent("MidBody")->setValue("n_undercargo",n_cargorow); //Bayの数を設定
                name = "UnderCargo";
                int rowint = (int)(test->getComponent("MidBody")->getValue("n_undercargo"));
                row = to_string(rowint);
            }
            else if (cargotype == 1) {
                test->getComponent("MidBody")->setValue("h_root", 16.5 + h_margin);
                test->getComponent("MidBody")->setValue("h_mid", 16.5 + h_margin);
                test->getComponent("MidBody")->setValue("h_tip", 6.5 + h_margin);
                n_cargorow = ((int)(n_cargorow_double/2.0))*2;
                test->getComponent("MidBody")->setValue("n_sidecargo",n_cargorow); //Bayの数を設定
                name = "SideCargo";
                int rowint = (int)(test->getComponent("MidBody")->getValue("n_sidecargo"));
                row = to_string(rowint);
            }
            else if (cargotype == 2) {
                test->getComponent("MidBody")->setValue("h_root", 16.5 + h_margin);
                test->getComponent("MidBody")->setValue("h_mid", 16.5 + h_margin);
                test->getComponent("MidBody")->setValue("h_tip", 16.5 + h_margin);
                n_cargorow = (int)n_cargorow_double;
                test->getComponent("MidBody")->setValue("n_rearcargo",n_cargorow); //Bayの数を設定
                name = "RearCargo";
                int rowint = (int)(test->getComponent("MidBody")->getValue("n_rearcargo"));
                row = to_string(rowint);
            }
            else {
                cout << "Error:This BWB doesn't belong to any type!!" << endl;
            }
        }

        else if (cargotype == 0) {
            test->getComponent("MidBody")->setValue("h_root", 14.75 + h_margin);
            test->getComponent("MidBody")->setValue("h_mid", 14.75 + h_margin);
            test->getComponent("MidBody")->setValue("h_tip", 8.25 + h_margin);
            n_cargorow = ((int)(n_cargorow_double/2.0))*2;
            test->getComponent("MidBody")->setValue("n_undercargo",n_cargorow); //Bayの数を設定
            name = "UnderCargo";
            int rowint = (int)(test->getComponent("MidBody")->getValue("n_undercargo"));
            row = to_string(rowint);
        }
        else if (cargotype == 1) {
            test->getComponent("MidBody")->setValue("h_root", 8.25 + h_margin);
            test->getComponent("MidBody")->setValue("h_mid", 8.25 + h_margin);
            test->getComponent("MidBody")->setValue("h_tip", 6.5 + h_margin);
            n_cargorow = ((int)(n_cargorow_double/2.0))*2;
            test->getComponent("MidBody")->setValue("n_sidecargo",n_cargorow); //Bayの数を設定
            name = "SideCargo";
            int rowint = (int)(test->getComponent("MidBody")->getValue("n_sidecargo"));
            row = to_string(rowint);
        }
        else if (cargotype == 2) {
            test->getComponent("MidBody")->setValue("h_root", 8.25 + h_margin);
            test->getComponent("MidBody")->setValue("h_mid", 8.25 + h_margin);
            test->getComponent("MidBody")->setValue("h_tip", 8.25 + h_margin);
            n_cargorow = (int)n_cargorow_double;
            test->getComponent("MidBody")->setValue("n_rearcargo",n_cargorow); //Bayの数を設定
            name = "RearCargo";
            int rowint = (int)(test->getComponent("MidBody")->getValue("n_rearcargo"));
            row = to_string(rowint);
        }
        else {
            cout << "Error:This BWB doesn't belong to any type!!" << endl;
        }

        

        if(!fout.is_open()) {  //開けなかったらエラーメッセージを吐く
            cout << "file can't be opened!" << endl;

            return 1;
        }

        test->reconstruct();
        test->setRequirements(B767_200ER());
        test->init();    //ポインタ変数testに格納されたBWBTypeオブジェクトに対してinit()してください。      


        /*fout << "----------MidBody----------" << endl; 
        fout << "----------independent variables----------" << endl; 
        fout << "l(胴体長さ): " << test->getComponent("MidBody")->getValue("l") << " ft" << endl;
        fout << "w_bay(Bay幅): " << test->getComponent("MidBody")->getValue("w_bay") << " ft"<< endl;
        fout << "n_bay(Bay数): " << test->getComponent("MidBody")->getValue("n_bay") << endl;
        fout << "taper(胴体テーパー比): " << test->getComponent("MidBody")->getValue("taper") << endl;
        fout << "l_sweep(胴体前縁後退角): " << test->getComponent("MidBody")->getValue("l_sweep") * 180 / pi << " deg"<< endl; 
        fout << "h_root(胴体根翼厚): " << test->getComponent("MidBody")->getValue("h_root") << endl; 
        fout << "h_tip(胴体端翼厚): " << test->getComponent("MidBody")->getValue("h_tip") << endl;
        fout << "n_undercargo(Under貨物列数): " << test->getComponent("MidBody")->getValue("n_undercargo") << endl;
        fout << "n_sidecargo(Side貨物列数): " << test->getComponent("MidBody")->getValue("n_sidecargo") << endl;
        fout << "n_rearcargo(Rear貨物列数): " << test->getComponent("MidBody")->getValue("n_rearcargo") << endl;
        fout << "----------dependent variables----------" << endl; 
        fout << "b(胴体スパン): " << test->getComponent("MidBody")->getValue("b") << " ft"<< endl;
        fout << "l_vessel(与圧区域長さ): " << test->getComponent("MidBody")->getValue("l_vessel") << " ft"<< endl;
        fout << "l_cabin(Cabin区域長さ): " << test->getComponent("MidBody")->getValue("l_cabin") << " ft"<< endl;
        fout << "tc_average(平均翼厚比): " << test->getComponent("MidBody")->getValue("tc_average") << endl; 
        fout << "mac(平均空力翼弦長): " << test->getComponent("MidBody")->getValue("mac") << " ft"<< endl;
        fout << "y_mac(平均空力翼弦y方向位置): " << test->getComponent("MidBody")->getValue("y_mac") << " ft"<< endl;
        fout << "x_ac(空力中心のノーズからのx方向距離): " << test->getComponent("MidBody")->getValue("x_ac") << " ft"<< endl;
        fout << "x_LE_kink(翼同結合部の前縁x位置): " << test->getComponent("MidBody")->getValue("x_LE_kink") << " ft" << endl;
        fout << "h_center(胴体中央部高さ): " << test->getComponent("MidBody")->getValue("h") << " ft"<< endl;
        fout << "A_max(胴体最大断面積): " << test->getComponent("MidBody")->getValue("A_max") << " ft^2"<< endl;
        fout << "S(胴体面積): " << test->getComponent("MidBody")->getValue("S") << " ft^2"<< endl;
        fout << "S_vessel(胴体与圧区域面積): " << test->getComponent("MidBody")->getValue("S_vessel") << " ft^2"<< endl;
        fout << "S_aft(胴体後方(後ろ桁以後)面積): " << test->getComponent("MidBody")->getValue("S_aft") << " ft^2"<< endl; 
        fout << "S_wet(胴体のみの濡れ面積): " << test->getComponent("MidBody")->getValue("S_wet") << " ft^2"<< endl; 
        fout << "aft_taper(胴体後方テーパー比): " << test->getComponent("MidBody")->getValue("aft_taper") << endl;
        fout << "sweep(胴体25％位置後退角): " << test->getComponent("MidBody")->getValue("sweep") * 180 / pi << " deg"<< endl;
        fout << "windshield(窓正面面積): " << test->getComponent("MidBody")->getValue("windshield") << endl;
        fout << "w_cargo(貨物1列辺りに必要な幅): " << test->getComponent("MidBody")->getValue("w_cargo") << " ft"<< endl;
        fout << "L_total(Cabinのために確保できる長さ(6席単位で)): " << test->getComponent("MidBody")->getValue("L_total") << " ft"<< endl;
        fout << endl;
        fout << "Cabin充填率: " << 155.0 / test->getComponent("MidBody")->getValue("L_total") << endl;
        fout << endl;
        fout << "h_root(胴体中央高さ): " << test->getComponent("MidBody")->getValue("h_root") << " ft"<< endl;
        fout << "L_cargo_total(貨物室のために確保できる長さ(2列単位で)): " << test->getComponent("MidBody")->getValue("L_cargo_total") << " ft"<< endl;
        fout << endl;
        fout << "Cargo充填率: " << 85.0 / test->getComponent("MidBody")->getValue("L_cargo_total") << endl;
        fout << endl;
        fout << "h_tip(端高さ): " << test->getComponent("MidBody")->getValue("h_tip") << " ft"<< endl;
        fout << "h_mid(Under貨物室端の高さ): " << test->getComponent("MidBody")->getValue("h_mid") << " ft"<< endl;
        fout << "h_tip(Side貨物室端の高さ): " << test->getComponent("MidBody")->getValue("h_tip") << " ft"<< endl;
        fout << endl;
        fout << "h_root: " << test->getComponent("MidBody")->getValue("h_root") << " ft" << endl;
        fout << "h_mid: " << test->getComponent("MidBody")->getValue("h_mid") << " ft" << endl;
        fout << "h_tip: " << test->getComponent("MidBody")->getValue("h_tip") << " ft" << endl;
        fout << "l: " << test->getComponent("MidBody")->getValue("l") << " ft" << endl;
        fout << "l_mid: " << test->getComponent("MidBody")->getValue("l_mid") << " ft" << endl;
        fout << "l_tip: " << test->getComponent("MidBody")->getValue("l_tip") << " ft" << endl;
        fout << "b_mid: " << test->getComponent("MidBody")->getValue("b_mid") << " ft" << endl;
        fout << "b: " << test->getComponent("MidBody")->getValue("b") << " ft" << endl;
        fout << "tc_root: " << test->getComponent("MidBody")->getValue("tc_root") << " ft" << endl;
        fout << "tc_mid: " << test->getComponent("MidBody")->getValue("tc_mid") << " ft" << endl;
        fout << "tc_tip: " << test->getComponent("MidBody")->getValue("tc_tip") << " ft" << endl;

        fout << endl;
        fout << "----------Wing----------" << endl;
        fout << "----------independent variables----------" << endl; 
        fout << "S(主翼面積): " << test->getComponent("Wing")->getValue("S") << " ft^2" << endl;
        fout << "b(主翼スパン): " << test->getComponent("Wing")->getValue("b") << " ft" << endl;
        fout << "taper(主翼テーパー比): " << test->getComponent("Wing")->getValue("taper") << endl; 
        fout << "sweep(主翼後退角): " << test->getComponent("Wing")->getValue("sweep") * 180 / pi << " deg" << endl;
        fout << "tc_root(主翼根翼厚比): " << test->getComponent("Wing")->getValue("tc_root") << endl;
        fout << "tc_tip(主翼端翼厚比): " << test->getComponent("Wing")->getValue("tc_tip") << endl;
        fout << "xc_m((x/c)max 最大厚み位置)): " << test->getComponent("Wing")->getValue("xc_m") << endl; 
        fout << "----------dependent variables----------" << endl; 
        fout << "AR(主翼アスペクト比): " << test->getComponent("Wing")->getValue("AR") << endl; 
        fout << "c_root(主翼根コード長): " << test->getComponent("Wing")->getValue("c_root") << " ft" << endl;
        fout << "c_tip(主翼端コード長): " << test->getComponent("Wing")->getValue("c_tip") << " ft" << endl;
        fout << "tc_average(平均翼厚比): " << test->getComponent("Wing")->getValue("tc_average") << endl; 
        fout << "tc_ratio(翼根翼端tc比): " << test->getComponent("Wing")->getValue("tc_ratio") << endl; 
        fout << "mac(平均空力翼弦長): " << test->getComponent("Wing")->getValue("mac") << " ft" << endl; 
        fout << "y_mac(平均空力翼弦位置): " << test->getComponent("Wing")->getValue("y_mac") << " ft" << endl;
        fout << "l_sweep(主翼前縁後退角): " << test->getComponent("Wing")->getValue("l_sweep") * 180 / pi << " deg" << endl;
        fout << "m_sweep(最大厚み位置後退角): " << test->getComponent("Wing")->getValue("m_sweep") * 180 / pi << " deg" << endl; 
        fout << "flap_span(フラップスパン比): " << test->getComponent("Wing")->getValue("flap_span") << endl; 
        fout << "df_TO(離陸時フラップ角度): " << test->getComponent("Wing")->getValue("df_TO") << " deg" << endl; 
        fout << "df_L(着陸時フラップ角度): " << test->getComponent("Wing")->getValue("df_L") << " deg" << endl;
        fout << "S_exp(主翼露出面積): " << test->getComponent("Wing")->getValue("S_exp") << " ft^2" << endl;
        fout << "S_wet(主翼濡れ面積): " << test->getComponent("Wing")->getValue("S_wet") << " ft^2" << endl;
        fout << "S_all(全機翼面積): " << test->getComponent("Wing")->getValue("S_all") << " ft^2" << endl;
        fout << "outer_mac(外翼の平均空力翼弦長): " << test->getComponent("Wing")->getValue("outer_mac") << " ft^2" << endl;
        fout << "outer_y_mac(外翼の平均空力翼弦y位置): " << test->getComponent("Wing")->getValue("outer_y_mac") << " ft^2" << endl;
        fout << "outer_x_ac(外翼の空力中心x位置): " << test->getComponent("Wing")->getValue("outer_x_ac") << " ft^2" << endl;
        fout << "all_x_ac(全機空力中心位置): " << test->getComponent("Wing")->getValue("all_x_ac") << " ft^2" << endl;
        fout << endl;
        fout << "----------Engine----------" << endl;
        fout << "----------independent variables----------" << endl; 
        fout << "N(エンジン個数): " << test->getComponent("Engine")->getValue("N") << endl; 
        fout << "W_eng(エンジン重量/1基): " << test->getComponent("Engine")->getValue("W_eng") << " lb" << endl;
        fout << "T_to(離陸推力/1基): " << test->getComponent("Engine")->getValue("T_to") << " lb" << endl;
        fout << "BPR(バイパス日): " << test->getComponent("Engine")->getValue("BPR") << endl; 
        fout << "d_eng(エンジン直径): " << test->getComponent("Engine")->getValue("d_eng") << " ft" << endl; 
        fout << "l_eng(エンジン長さ): " << test->getComponent("Engine")->getValue("l_eng") << " ft" << endl; 
        fout << "h_nacelle(ナセル高さ): " << test->getComponent("Engine")->getValue("h_nacelle") << " ft" << endl;
        fout << "b_nacelle(ナセル幅): " << test->getComponent("Engine")->getValue("b_nacelle") << " ft" << endl;
        fout << "l_nacelle(ナセル長さ): " << test->getComponent("Engine")->getValue("l_nacelle") << " ft" << endl; 
        fout << "----------dependent variables----------" << endl; 
        fout << "S_wet(濡れ面積): " << test->getComponent("Engine")->getValue("S_wet") << " ft^2" << endl; 
        fout << endl;*/


        auto Performance = static_cast<BasicPerformance *>(test->getModule("Performance"));
        /*fout << "----------Performance----------" << endl;
        fout << "TOFL(離陸距離):" << Performance->TOFL(0.0) << "ft" << endl;
        fout << "LFL(着陸距離):" << Performance->LFL(0.0) << "ft" << endl;
        fout << "SSC(セカンドセグメント上昇勾配):" << Performance->SSC() << endl;
        fout << "ICAC(初期巡航高度余裕):" << Performance->ICAC() << "ft/min" << endl;*/


        auto Mission = static_cast<BasicJet *>(test->getModule("Mission"));
        auto Weight = static_cast<BradleyBWB *>(test->getModule("Weight"));
        
        fout << Mission->getLD_cr() << ",";
        fout << 1.0 / Mission->getLD_cr() << ",";
        fout << Weight->getWeight("TakeOff") << ",";
        fout << Weight->getWeight("Fuel") << ",";
        fout << Weight->getWeight("OperationalEmpty") << ",";
        fout << Weight->getWeight("Empty") << ",";
        fout << Mission->weightFraction() << ",";
        fout << cargotype << ",";
        fout << n_bay << ",";
        fout << n_cargorow << ",";
        fout << T_to << ",";
        fout << test->getComponent("Wing")->getValue("S_all") << ",";
        fout << test->getComponent("MidBody")->getValue("S_vessel") << ",";

        /*fout << "W_OE: " << Weight->getWeight("OperationalEmpty") << "lb" << endl;
        fout << "W_E: " << Weight->getWeight("Empty") << "lb" << endl;
        fout << "W_PL: " << Weight->getWeight("Payload") << "lb" << endl;
        if (Weight->getWeight("Fuel") < WF) {
            WFmin = i;
            WF = Weight->getWeight("Fuel");
        }*/

        Atmosphere *atm = new Atmosphere();
        auto req = test->getRequirements();
        auto ard = static_cast<AerodynamicsModule *>(test->getModule("Aerodynamics"));
        auto wgt = static_cast<WeightModule *>(test->getModule("Weight"));
        double V, M, h, Re, Cf, FF, Q, S_wet, nu;
    
        
        S = test->getComponent("Wing")->getValue("S_all");
        V = req->getValue("V_cr") / fts_to_kt;
        M = req->getValue("M_cr");
        h = req->getValue("h_cr");
        nu = atm->nu(h);
        /*fout << "V_cr(巡航速度): " << V << endl;
        fout << "M_cr(巡航マッハ数): " << M << endl;
        fout << "h_cr(巡航高度): " << h << endl;*/
        double q = 0.5 * pow(V, 2) * atm->rho(h);
        double CL = (wgt->getWeight("TakeOff") * 0.955) / q / test->getComponent("Wing")->getValue("S_all");
        double CD0 = ard->CD_fric(M, h) / 0.97 + ard->CD_wave(M, CL);//depends on CL
        /*fout << "CD0: " << CD0 << endl;          
        fout << "CD_fric(摩擦抵抗係数): " << ard->CD_fric(M, h) << endl;
        fout << "CD_wave(造波抵抗係数): " << ard->CD_wave(M, CL) << endl;*/

        double K = ard->K(M);
        /*double CD = CD0 + K * CL * CL;
        double S_wet_wing = test->getComponent("Wing")->getValue("S_wet");
        double S_wet_midbody = test->getComponent("MidBody")->getValue("S_wet");
        double S_wet_engine = test->getComponent("Engine")->getValue("S_wet");
        fout << "S_wet(全濡れ面積): " << S_wet_wing + S_wet_midbody + S_wet_engine << "ft^2" << endl;
        fout << "K@cruise: " << ard->K(M) << endl; 
        fout << "CL(揚力係数): " << CL << endl;
        fout << "CD(抵抗係数): " << CD << endl;
        fout << "D(抵抗): " << q * S * CD << " lb" << endl;
        fout << "L(揚力): " << q * S * CL << " lb" << endl;
        fout << "L/D" << CL / (CD0 + K * CL * CL) << endl;*/


        /* wing */ /*Q = 1.0;
        FF = FF_liftsur(M,
                        test->getComponent("Wing")->getValue("xc_m"),
                        test->getComponent("Wing")->getValue("tc_average"),
                        test->getComponent("Wing")->getValue("m_sweep"));
        S_wet = test->getComponent("Wing")->getValue("S_wet");
        double r_lam = 0.15; // rate of laminar flow
        Re = Re_(M, V, nu, test->getComponent("Wing")->getValue("mac"));
        Cf = r_lam * 1.328 / sqrt(Re); // laminar
        Cf += (1.0 - r_lam) * Cf_(Re, M); // turbulent
        double CD_wng = Q * Cf * FF * S_wet / S;
        fout << "CD_wng(主翼の摩擦抵抗係数): " << CD_wng << endl;*/

        /* fuselage */ /*Q = 1.0;*/
        //double f = gmt->getComponent("MidBody")->getValue("l") / sqrt(4.0 / pi * gmt->getComponent("MidBody")->getValue("A_max"));
        /*FF = FF_liftsur(M,
                        test->getComponent("MidBody")->getValue("xc_m"),
                        test->getComponent("MidBody")->getValue("tc_average"),
                        test->getComponent("MidBody")->getValue("m_sweep"));
        S_wet = test->getComponent("MidBody")->getValue("S_wet");
        r_lam = 0.00; // rate of laminar flow
        Re = Re_(M, V, nu, test->getComponent("MidBody")->getValue("l"));
        Cf = r_lam * 1.328 / sqrt(Re); // laminar
        Cf += (1.0 - r_lam) * Cf_(Re, M); // turbulent//胴体翼についてもこの式が適用できるとした。
        double CD_fus = Q * Cf * FF * S_wet / S;
        fout << "FF(胴体のFormFactor): " << FF << endl;
        fout << "S_wet(胴体の濡れ面積): " << S_wet << endl;
        fout << "Re(胴体のレイノルズ数): " << Re << endl;
        fout << "Cf(胴体のCf): " << Cf << endl;
        fout << "CD_fus(胴体の摩擦抵抗係数): " << CD_fus << endl;*/

        /* nacelle */ /*Q = 1.0;
        double f = test->getComponent("Engine")->getValue("l_nacelle") / (test->getComponent("Engine")->getValue("b_nacelle") + test->getComponent("Engine")->getValue("h_nacelle")) / 0.5;
        FF = 1.0 + 0.35 / f;
        S_wet = test->getComponent("Engine")->getValue("S_wet");
        Re = Re_(M, V, nu, test->getComponent("Engine")->getValue("l_nacelle"));
        Cf = Cf_(Re, M);
        double CD_nac = Q * Cf * FF * S_wet / S * test->getComponent("Engine")->getValue("N");
        fout << "CD_nac(ナセルの摩擦抵抗係数): " << CD_nac << endl;*/
        /* windshield */
        /*double dCdcock = 0.07 * test->getComponent("MidBody")->getValue("windshield") / S;
        fout << "dCdcock(コックピットの摩擦抵抗係数): " << dCdcock << endl;
        fout << endl;

        delete atm;


        fout << endl;
        fout << "----------以下、チェック用です----------" << endl;*/


        double A = test->getComponent("Wing")->getValue("AR");
        A *= test->getComponent("Wing")->getValue("S") / (test->getComponent("Wing")->getValue("S_exp") + test->getComponent("MidBody")->getValue("S"));
        /*double e;
        e = 4.61 * (1.0 - 0.045 * pow(A, 0.68)) * pow(cos(test->getComponent("Wing")->getValue("l_sweep")), 0.15) - 3.1;
        fout << "l_sweep(主翼前縁後退角): " << test->getComponent("Wing")->getValue("l_sweep") * 180 / pi << endl;
        fout << "AR(主翼アスペクト比): " << test->getComponent("Wing")->getValue("AR") << endl;
        fout << "S(主翼面積): " << test->getComponent("Wing")->getValue("S") << endl;
        fout << "S_exp(主翼の内外に出ている露出面積): " << test->getComponent("Wing")->getValue("S_exp") << endl;
        fout << "S(胴体面積): " << test->getComponent("MidBody")->getValue("S") << endl;*/

        fout << A << ",";
        fout << test->getComponent("Wing")->getValue("b") << ",";
        fout << test->getComponent("MidBody")->getValue("l") << ",";
        fout << test->getComponent("MidBody")->getValue("h_root") << ",";
        fout << test->getComponent("MidBody")->getValue("tc_average") << ",";

        if (type == "DD") { 
            fout << 130.0 / test->getComponent("MidBody")->getValue("L_total") / 2.0 << ",";
        }
        else {
            fout << 130.0 / test->getComponent("MidBody")->getValue("L_total") << ",";
        }        
        fout << 63.98 / test->getComponent("MidBody")->getValue("L_cargo_total") << ",";

        fout << test->getComponent("MidBody")->getValue("l") << ",";
        fout << test->getComponent("MidBody")->getValue("l_vessel") << ",";
        fout << test->getComponent("MidBody")->getValue("l_cabin") << ",";
        fout << test->getComponent("MidBody")->getValue("w_bay") << ",";
        fout << test->getComponent("MidBody")->getValue("n_bay") << ",";
        fout << test->getComponent("MidBody")->getValue("b") << ",";
        fout << test->getComponent("MidBody")->getValue("b_cabin") << ",";
        fout << test->getComponent("MidBody")->getValue("taper") << ",";
        fout << test->getComponent("MidBody")->getValue("l_sweep") * 180 / pi << ","; 
        fout << test->getComponent("MidBody")->getValue("h_root") << ","; 
        fout << test->getComponent("MidBody")->getValue("h_tip") << ",";
        fout << test->getComponent("MidBody")->getValue("n_undercargo") << ",";
        fout << test->getComponent("MidBody")->getValue("n_sidecargo") << ",";
        fout << test->getComponent("MidBody")->getValue("n_rearcargo") << ",";


        fout << test->getComponent("Wing")->getValue("S") << ",";
        fout << test->getComponent("Wing")->getValue("b") << ",";
        fout << test->getComponent("Wing")->getValue("taper") << ","; 
        fout << test->getComponent("Wing")->getValue("sweep") * 180 / pi << ",";
        fout << test->getComponent("Wing")->getValue("tc_root") << ",";
        fout << test->getComponent("Wing")->getValue("tc_tip") << ",";
        fout << test->getComponent("Wing")->getValue("xc_m") << ",";
        fout << test->getComponent("MidBody")->getValue("mac") << ",";
        fout << test->getComponent("MidBody")->getValue("y_mac") << ",";
        fout << test->getComponent("MidBody")->getValue("x_ac") << ",";
        fout << test->getComponent("Wing")->getValue("outer_mac") << ",";
        fout << test->getComponent("Wing")->getValue("outer_y_mac") << ",";
        fout << test->getComponent("Wing")->getValue("outer_x_ac") << ",";
        fout << test->getComponent("Wing")->getValue("all_mac") << ","; 
        fout << test->getComponent("Wing")->getValue("all_y_mac") << ",";
        fout << test->getComponent("Wing")->getValue("all_x_ac") << ",";
        fout << Weight->getWeight("CG_BW") << ",";
        fout << Weight->getWeight("CG_FW") << ",";


        fout << test->getComponent("Engine")->getValue("N") << ","; 
        fout << test->getComponent("Engine")->getValue("W_eng") << ",";
        fout << test->getComponent("Engine")->getValue("T_to") << ",";
        fout << test->getComponent("Engine")->getValue("BPR") << ","; 
        fout << test->getComponent("Engine")->getValue("d_eng") << ","; 
        fout << test->getComponent("Engine")->getValue("l_eng") << ","; 

        fout << CD0 << ",";
        fout << K << ",";
        fout << CL << ",";
        fout << ard->CD_fric(M, h) << ",";
        fout << ard->CD_wave(M, CL) << ",";

        fout << Performance->TOFL(0.0) << ",";
        fout << Performance->LFL(0.0) << ",";
        fout << Performance->SSC() << ",";
        fout << Performance->ICAC() << ",";



        fout << test->getComponent("MidBody")->getValue("l") << ",";
        fout << test->getComponent("MidBody")->getValue("l_sweep") * 180 / pi << ",";
        fout << test->getComponent("MidBody")->getValue("b") << ",";
        fout << test->getComponent("MidBody")->getValue("l_tip") << ",";
        fout << test->getComponent("Wing")->getValue("l_sweep") * 180 / pi << ",";
        fout << test->getComponent("Wing")->getValue("b") << ",";
        fout << test->getComponent("Wing")->getValue("c_tip") << ",";

        fout << test->getComponent("MidBody")->getValue("h_root") << ",";

        fout << test->getComponent("MidBody")->getValue("h_tip") << endl;

        
        /*fout << "e(l_sweep>30)(主翼前縁後退角が30°より大きい場合の主翼のオズワルド数): " << e << endl;
        e = 1.78 * (1.0 - 0.045 * pow(A, 0.68)) - 0.64;
        fout << "e(l_sweep<30)(主翼前縁後退角が30°以下の場合の主翼のオズワルド数): " << e << endl;




        //Estimate MDD_wing
        //Rinoie Method
        double swp_W_rad = test->getComponent("Wing")->getValue("sweep");
        double swp_W_deg = swp_W_rad * 180 / pi;
        double AR_W = test->getComponent("Wing")->getValue("AR");
        double delta_MDD_W;
        double K_W = 0.0001 * swp_W_deg * swp_W_deg - 0.00165 * swp_W_deg + 0.5533;
        if (0 <= 9.5 - 34 / (AR_W*AR_W)) {
            delta_MDD_W = 0.11+(9.5-34/(AR_W*AR_W))*(pow(10,-6)*pow(swp_W_deg,2.5) -0.01);
        }
        else {
            delta_MDD_W = 0.11;
        }
        
        double tc_ave_W = test->getComponent("Wing")->getValue("tc_average");
        double MDD_W_Douglas = 0.828 + delta_MDD_W + 1.375 * (0.08 - tc_ave_W * 0.6) * cos(swp_W_rad)
        -CL * (0.05 + K_W * (tc_ave_W * 0.6 - 0.04)) - 0.05 * CL;
        double MDD_W_Boeing = MDD_W_Douglas - 0.06;//Drag Divergent Mach Number of Wing(Boing Method)


        //Estimate MDD_body by Rinoie new Method
        double swp_B_rad = test->getComponent("MidBody")->getValue("sweep");
        double swp_B_deg = swp_W_rad * 180 / pi;
        double AR_B = pow(test->getComponent("MidBody")->getValue("b") , 2) / test->getComponent("MidBody")->getValue("S");
        double K_B = 0.0001 * swp_B_deg * swp_B_deg - 0.00165 * swp_B_deg + 0.5533;
        double delta_MDD_B;
        if (0 <= 9.5 - 34 / (AR_B*AR_B)) {
            delta_MDD_B = 0.11+(9.5-34/(AR_B*AR_B))*(pow(10,-6)*pow(swp_B_deg,2.5) -0.01);
        }
        else {
            delta_MDD_B = 0.11;
        }
        
        double tc_ave_B = test->getComponent("MidBody")->getValue("tc_average");
        double MDD_B_Douglas = 0.828 + delta_MDD_B + 1.375 * (0.08 - tc_ave_B * 0.6) * cos(swp_B_rad)
        -CL * (0.05 + K_B * (tc_ave_B * 0.6 - 0.04)) - 0.05 * CL;
        double MDD_B_Boeing = MDD_B_Douglas - 0.06;//Drag Divergent Mach Number of Wing(Boing Method)


        //Estimate MDD_body by cross-sectional-Area method 
        
        double E_WD = 1.8;
        double swp = test->getComponent("Wing")->getValue("l_sweep") * 180.0 / pi;
        double Amax = test->getComponent("MidBody")->getValue("l") * test->getComponent("MidBody")->getValue("tc_root") * test->getComponent("MidBody")->getValue("b") * 0.8 + 112.6 * 0.5 * test->getComponent("Wing")->getValue("tc_average") * 14.0;
        double Dq_SH = 4.5 * pi * pow(1.5 * Amax / test->getComponent("MidBody")->getValue("l"), 2.0);
    
        double MDD0 = 0.1269 * swp * pi / 180.0 + 0.7764;
        double LFDD = -0.002 * CL * CL - 0.0018 * CL + 1.0;
        double MDD_B = MDD0 * LFDD - 0.05 * CL;

        //True MDD
        double MDD = min(MDD_W_Boeing, min(MDD_B_Boeing, MDD_B));

        double Mcrit = MDD - 0.08;


        /*fout << "MDD_W_Boeing(Boeing定義での主翼の抵抗発散マッハ数): " << MDD_W_Boeing << endl;
        fout << "MDD_B_Boeing(Boeing定義での胴体の抵抗発散マッハ数): " << MDD_B_Boeing << endl;
        fout << "MDD_B(断面積法による胴体の抵抗発散マッハ数): " << MDD_B << endl;
        fout << "MDD(機体全体での抵抗発散マッハ数): " << MDD << endl;
        fout << "Mcrit(臨界マッハ数): " << Mcrit << endl;*/






        /* wing */
        /*Component *cmp = test->getComponent("Wing");
        double W_TO = Weight->getWeight("TakeOff");
        double W_mzf = W_TO - Weight->getWeight("Fuel");
        double tr = cmp->getValue("c_root") * cmp->getValue("tc_root");
        double Wing_weight = 0.0017 * W_mzf
        * pow(cmp->getValue("b") / cos(cmp->getValue("m_sweep")), 0.75)
        * (1.0 + pow(6.25 / cmp->getValue("b") * cos(cmp->getValue("m_sweep")), 0.5))
        * pow(3.8, 0.55)
        * pow(cmp->getValue("b") * cmp->getValue("S_exp") / tr / W_mzf / cos(cmp->getValue("m_sweep")), 0.3);


        //この規模のBWBでBradleyの推算を使うと、1%のaftbodyで10%のエンジンを支えることになる。
        //Kuntawalaのようにaftbodyの面積もまとめて、次の推算を使ってみるとよいかもしれない。
        /* cabin */
        /*cmp = test->getComponent("MidBody");
        S = cmp->getValue("S_vessel");
        double Cabin_weight = 5.698865 * 0.316422 * pow(W_TO, 0.166552) * pow(S, 1.061158);
    
        /* aft body */
        /*S = cmp->getValue("S_aft");
        tr = cmp->getValue("aft_taper");
        cmp = test->getComponent("Engine");
        double N = cmp->getValue("N");
        double AftBody_weight = (1.0 + 0.05 * N) * 0.53 * S * pow(W_TO, 0.2) * (tr + 0.5);
    
        /* propulsion systems */
        /*double Prop_weight;
        if (cmp->getValue("W_eng") > 22000.0) {
            Prop_weight = (0.065 * cmp->getValue("T_to") + 1.16 * cmp->getValue("W_eng") + 5950.0) * cmp->getValue("N");
        }
        else Prop_weight = (0.065 * cmp->getValue("T_to") + 1.43 * cmp->getValue("W_eng"))* cmp->getValue("N");
    
        /* main gear */
        /*double MainGear_weight = (40.0 + 0.16 * pow(W_TO, 0.75) + 0.019 * W_TO + 1.5e-5 * pow(W_TO, 1.5));
    
        /* nose gear */
        /*double NoseGear_weight = (20.0 + 0.10 * pow(W_TO, 0.75) + 2.0e-6 * pow(W_TO, 1.5));
    
        /* systems & equipment */
        /*double Range = test->getRequirements()->getValue("R_cr");
        double N_crew = test->getRequirements()->getValue("N_crew");
        double N_pax = test->getRequirements()->getValue("N_pax");
        double System_weight;
        if (Range < 3000) {
            System_weight = 0.14 * W_TO + 187.0 * N_crew + 15.0 * N_pax;
        }
        else if (Range < 6000) {
            System_weight = 0.11 * W_TO + 187.0 * N_crew + 26.0 * N_pax;
        }
        else {
            System_weight = 0.08 * W_TO + 187.0 * N_crew + 35.0 * N_pax;
        }
    
        /* crew */
        /*double Crew_weight = 205.0 * N_crew;

        fout << "Wing_weight: " << Wing_weight << endl;
        fout << "Cabin_weight: " << Cabin_weight << endl;
        fout << "AftBody_weight: " << AftBody_weight << endl;
        fout << "Prop_weight: " << Prop_weight << endl;
        fout << "MainGear_weight: " << MainGear_weight << endl;
        fout << "NoseGear_weight: " << NoseGear_weight << endl;
        fout << "System_weight: " << System_weight << endl;
        fout << "Crew_weight: " << Crew_weight << endl; 

        fout << endl;

        fout << "cg_wing: " << test->getComponent("Wing")->getValue("cg") << " ft" << endl;
        fout << "cg_vessel: " << test->getComponent("MidBody")->getValue("cg_vessel") << " ft" << endl;
        fout << "cg_aft: " << test->getComponent("MidBody")->getValue("cg_aft") << " ft" << endl;
        fout << "cg_maingear: " << test->getComponent("MidBody")->getValue("cg_maingear") << " ft" << endl;
        fout << "cg_nosegear: " << test->getComponent("MidBody")->getValue("cg_nosegear") << " ft" << endl;

        fout << endl;

        fout << "CG_BW: " << Weight->getWeight("CG_BW") << " ft" << endl;
        fout << "CG_FW: " << Weight->getWeight("CG_FW") << " ft" << endl;
        fout << endl;






        double rho = atm->rho(0);
        /* load modules */
    
        /*double SA, SF, SFR, SB;
    
        double Vs_0 = sqrt(test->getRequirements()->getValue("WL_max") * wgt->getWeight("TakeOff") / test->getComponent("Wing")->getValue("S_all") * 2.0 / rho / ard->getConstant("CLmax_L"));
        double V_A = 1.3 * Vs_0;
        double V_TD = 0.9 * V_A;
        double r = pow( (V_A + V_TD) /2.0, 2.0) / atm->g() / (1.2 - 1.0);
        double gamma = 3.0 * pi / 180.0;
        double hF = r * gamma * (gamma / 2.0);
        double mu = 0.3;
    
        /* approach */
        //SA = (50.0 - hF) / tan(gamma);
        /* flare */
        //SF = r * gamma;
        /* free roll */
        //SFR = 2.0 * V_TD;
        /* braking */
        /*double KT = -mu;
        double KA = -ard->CD_fric(0.2, 0) / 0.97 - ard->dCD_flap("L") - ard->dCD_gear();
        KA *= rho * test->getComponent("Wing")->getValue("S_all") / (2.0 * test->getRequirements()->getValue("WL_max") * wgt->getWeight("TakeOff"));
        SB = 1.0 / (2.0 * atm->g() * KA) * log(KT / (KT + KA * V_TD * V_TD));
        delete atm;
        fout << "V_A(Approach速度): " << V_A << " ft/s" << endl;
        fout << "SA(Approsch距離): " << SA << " ft" << endl;
        fout << "SF(Flare距離): " << SF << " ft" << endl;
        fout << "SFR(FreeRoll距離): " << SFR << " ft" << endl;
        fout << "SB(Brake距離): " << SB << " ft" << endl;
        fout << "LFL(着陸距離): " << 1.66*(SA+SF+SFR+SB) << " ft" << endl; */
        






        //fout.close(); //ファイルを閉じる
        //cout << "written in file!" << endl;


    }
    //cout << "WF minimum: " << WFmin << endl;

    return 0;
}


//! Reynolds number
inline double Re_(double M, //!< Mach number
                  double V, //!< Velocity (in ft/s)
                  double nu, //!< Kinetic viscousity
                  double ref //!< Reference length
) {
    double Re = V * ref / nu; // ref: reference length (for example, mac)
    double k = 2.08e-5; // skin roughness factor (smooth paint)
    
    double cutoff_Re = 38.21 * pow((ref / k), 1.053);
    
    if (cutoff_Re < Re) Re = cutoff_Re;
    return Re;
}

//! skin friction coefficient (turbulent)
inline double Cf_(double Re, //!< Reynolds number
                  double M //!< Mach number
) {
    return 0.455 / (pow(log10(Re), 2.58) * pow(1.0 + 0.144 * M * M, 0.65));
}

//! form factor for lift surfaces
inline double FF_liftsur(double M,
                         double x,
                         double t,
                         double m) {
    return (1.0 + 0.6 / x * t + 100.0 * pow(t, 4))
    * (1.34 * pow(M, 0.18) * pow(cos(m), 0.28));
}
