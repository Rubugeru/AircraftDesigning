var class_stardust_plus_1_1_b_w_b_type =
[
    [ "BWBType", "class_stardust_plus_1_1_b_w_b_type.html#abaf81bb461fb75a143cbe729b97722d2", null ],
    [ "~BWBType", "class_stardust_plus_1_1_b_w_b_type.html#a1356914a67220c065d591530f852de9e", null ],
    [ "init", "class_stardust_plus_1_1_b_w_b_type.html#a68d7fe7c5ba44ef72318c086a22263f3", null ],
    [ "init", "class_stardust_plus_1_1_b_w_b_type.html#a43b233324646e2c03f15958d05b63f95", null ],
    [ "reconstruct", "class_stardust_plus_1_1_b_w_b_type.html#a7e92cac59f1c4cc8927d18130f13dd9c", null ],
    [ "saveData", "class_stardust_plus_1_1_b_w_b_type.html#a73be62e012f28754be2df9acf04a892b", null ],
    [ "saveData", "class_stardust_plus_1_1_b_w_b_type.html#a52599fa81410348fbfe6a646c5acf802", null ]
];