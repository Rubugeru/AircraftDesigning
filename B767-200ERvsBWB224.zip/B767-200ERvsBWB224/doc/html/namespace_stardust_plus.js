var namespace_stardust_plus =
[
    [ "AerodynamicsModule", "class_stardust_plus_1_1_aerodynamics_module.html", "class_stardust_plus_1_1_aerodynamics_module" ],
    [ "Atmosphere", "class_stardust_plus_1_1_atmosphere.html", "class_stardust_plus_1_1_atmosphere" ],
    [ "BasicJet", "class_stardust_plus_1_1_basic_jet.html", "class_stardust_plus_1_1_basic_jet" ],
    [ "BasicPerformance", "class_stardust_plus_1_1_basic_performance.html", "class_stardust_plus_1_1_basic_performance" ],
    [ "BradleyBWB", "class_stardust_plus_1_1_bradley_b_w_b.html", "class_stardust_plus_1_1_bradley_b_w_b" ],
    [ "BWBType", "class_stardust_plus_1_1_b_w_b_type.html", "class_stardust_plus_1_1_b_w_b_type" ],
    [ "Component", "class_stardust_plus_1_1_component.html", "class_stardust_plus_1_1_component" ],
    [ "EstimationModule", "class_stardust_plus_1_1_estimation_module.html", "class_stardust_plus_1_1_estimation_module" ],
    [ "GeometrySet", "class_stardust_plus_1_1_geometry_set.html", "class_stardust_plus_1_1_geometry_set" ],
    [ "LiftingBody", "class_stardust_plus_1_1_lifting_body.html", "class_stardust_plus_1_1_lifting_body" ],
    [ "LiftSurface", "class_stardust_plus_1_1_lift_surface.html", "class_stardust_plus_1_1_lift_surface" ],
    [ "MissionModule", "class_stardust_plus_1_1_mission_module.html", "class_stardust_plus_1_1_mission_module" ],
    [ "RaymerTransonic", "class_stardust_plus_1_1_raymer_transonic.html", "class_stardust_plus_1_1_raymer_transonic" ],
    [ "Requirements", "class_stardust_plus_1_1_requirements.html", "class_stardust_plus_1_1_requirements" ],
    [ "RinoieTransport", "class_stardust_plus_1_1_rinoie_transport.html", "class_stardust_plus_1_1_rinoie_transport" ],
    [ "TransonicBWB", "class_stardust_plus_1_1_transonic_b_w_b.html", "class_stardust_plus_1_1_transonic_b_w_b" ],
    [ "TubeFuselage", "class_stardust_plus_1_1_tube_fuselage.html", "class_stardust_plus_1_1_tube_fuselage" ],
    [ "TubeWingType", "class_stardust_plus_1_1_tube_wing_type.html", "class_stardust_plus_1_1_tube_wing_type" ],
    [ "Turbofan", "class_stardust_plus_1_1_turbofan.html", "class_stardust_plus_1_1_turbofan" ],
    [ "WeightModule", "class_stardust_plus_1_1_weight_module.html", "class_stardust_plus_1_1_weight_module" ]
];