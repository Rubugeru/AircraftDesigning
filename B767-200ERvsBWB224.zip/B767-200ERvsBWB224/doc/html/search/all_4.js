var searchData=
[
  ['estimationmodule',['EstimationModule',['../class_stardust_plus_1_1_estimation_module.html',1,'StardustPlus::EstimationModule'],['../class_stardust_plus_1_1_estimation_module.html#a973880d2da6798fd7a8ab5583de831b1',1,'StardustPlus::EstimationModule::EstimationModule()']]],
  ['estimationmodule_2ecpp',['estimationmodule.cpp',['../estimationmodule_8cpp.html',1,'']]],
  ['estimationmodule_2eh',['estimationmodule.h',['../estimationmodule_8h.html',1,'']]]
];
