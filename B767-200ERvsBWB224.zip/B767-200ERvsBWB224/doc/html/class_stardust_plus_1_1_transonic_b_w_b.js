var class_stardust_plus_1_1_transonic_b_w_b =
[
    [ "TransonicBWB", "class_stardust_plus_1_1_transonic_b_w_b.html#ad737e167b916261e35a0ed2c5fa8d1ee", null ],
    [ "~TransonicBWB", "class_stardust_plus_1_1_transonic_b_w_b.html#a09310d7967a33d4262ac4d6cb0ed20aa", null ],
    [ "CD_fric", "class_stardust_plus_1_1_transonic_b_w_b.html#ac3a53c22025b372297690276e9258e3e", null ],
    [ "CD_wave", "class_stardust_plus_1_1_transonic_b_w_b.html#a1a6205fcb278204b3a9cfe37517b1f37", null ],
    [ "CLa", "class_stardust_plus_1_1_transonic_b_w_b.html#a8326d839d33c2743dbc2ee8606c1867e", null ],
    [ "dCD_flap", "class_stardust_plus_1_1_transonic_b_w_b.html#ae971dad54f168c88c7905c831e8a829b", null ],
    [ "dCD_gear", "class_stardust_plus_1_1_transonic_b_w_b.html#ad329504fe1fd122df96342fa80ddc687", null ],
    [ "init", "class_stardust_plus_1_1_transonic_b_w_b.html#aa60d5a40fcd1d9fa6c6a62cd0cb518b6", null ],
    [ "K", "class_stardust_plus_1_1_transonic_b_w_b.html#ace44a92de0afa98f1a75ad4339ade0f6", null ]
];