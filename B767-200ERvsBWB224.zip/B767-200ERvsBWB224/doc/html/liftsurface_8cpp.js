var liftsurface_8cpp =
[
    [ "N_assign", "liftsurface_8cpp.html#a194c6fb01911583e7cd9115cfa1d7e55", null ],
    [ "pi", "liftsurface_8cpp.html#a1daf785e3f68d293c7caa1c756d5cb74", null ]
];