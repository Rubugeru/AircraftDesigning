var class_stardust_plus_1_1_bradley_b_w_b =
[
    [ "BradleyBWB", "class_stardust_plus_1_1_bradley_b_w_b.html#aea70b5b861bddcf8465c60e6ff1469da", null ],
    [ "~BradleyBWB", "class_stardust_plus_1_1_bradley_b_w_b.html#a9366bbb4a0a7c26fa9282af9f9af5e46", null ],
    [ "init", "class_stardust_plus_1_1_bradley_b_w_b.html#a537b67fe44df7bdbf0a2a13861eb1043", null ],
    [ "setComponentWeights", "class_stardust_plus_1_1_bradley_b_w_b.html#ae20dc985341eee2ff668a1e57536bf88", null ],
    [ "convergence_fail", "class_stardust_plus_1_1_bradley_b_w_b.html#a92aaeae187434f64c40d02e8de25e28d", null ]
];