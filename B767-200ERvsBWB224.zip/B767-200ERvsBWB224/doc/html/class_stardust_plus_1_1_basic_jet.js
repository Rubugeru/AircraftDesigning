var class_stardust_plus_1_1_basic_jet =
[
    [ "BasicJet", "class_stardust_plus_1_1_basic_jet.html#afb5467878edfcf270658732c1f748be2", null ],
    [ "~BasicJet", "class_stardust_plus_1_1_basic_jet.html#adb9e14b79310e5ca264e6069345442a2", null ],
    [ "getLD_cr", "class_stardust_plus_1_1_basic_jet.html#a453df06683954162a1bda620fa0fac5f", null ],
    [ "init", "class_stardust_plus_1_1_basic_jet.html#a541cf11eb16fc72c87ce7841db2c7c8b", null ],
    [ "weightFraction", "class_stardust_plus_1_1_basic_jet.html#a908cfc61ce46c315d41fe115b0a7b1c9", null ],
    [ "ff", "class_stardust_plus_1_1_basic_jet.html#afc4f696a1b22fcdec76bae7226e90857", null ]
];