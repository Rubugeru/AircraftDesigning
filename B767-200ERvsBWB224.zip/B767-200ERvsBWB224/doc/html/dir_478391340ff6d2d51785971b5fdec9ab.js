var dir_478391340ff6d2d51785971b5fdec9ab =
[
    [ "atmosphere.cpp", "atmosphere_8cpp.html", null ],
    [ "atmosphere.h", "atmosphere_8h.html", [
      [ "Atmosphere", "class_stardust_plus_1_1_atmosphere.html", "class_stardust_plus_1_1_atmosphere" ]
    ] ],
    [ "requirements.cpp", "requirements_8cpp.html", null ],
    [ "requirements.h", "requirements_8h.html", [
      [ "Requirements", "class_stardust_plus_1_1_requirements.html", "class_stardust_plus_1_1_requirements" ]
    ] ]
];