var class_stardust_plus_1_1_aerodynamics_module =
[
    [ "AerodynamicsModule", "class_stardust_plus_1_1_aerodynamics_module.html#a50d259d7ecfc520bc9605d6b0d8cd073", null ],
    [ "~AerodynamicsModule", "class_stardust_plus_1_1_aerodynamics_module.html#a6369e24fa3bec73e3a52713cdf7261c7", null ],
    [ "CD_fric", "class_stardust_plus_1_1_aerodynamics_module.html#a9bb78ec59bbdd12139db52b4bedd5c75", null ],
    [ "CD_wave", "class_stardust_plus_1_1_aerodynamics_module.html#a36b826305df53cf61e16636c976a0cdc", null ],
    [ "CLa", "class_stardust_plus_1_1_aerodynamics_module.html#af63f69fc63b647ce02da317ad6b1751d", null ],
    [ "dCD_flap", "class_stardust_plus_1_1_aerodynamics_module.html#acbc6202801d6cdc28a92fd47c7a35c02", null ],
    [ "dCD_gear", "class_stardust_plus_1_1_aerodynamics_module.html#aa61a4ad0c2ad5cba7ffc7ed4fcb44f44", null ],
    [ "K", "class_stardust_plus_1_1_aerodynamics_module.html#a73ad661cf63177fa07b2acf80506b56a", null ]
];