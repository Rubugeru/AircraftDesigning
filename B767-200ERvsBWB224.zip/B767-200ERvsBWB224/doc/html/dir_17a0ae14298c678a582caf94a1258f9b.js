var dir_17a0ae14298c678a582caf94a1258f9b =
[
    [ "aeromodels", "dir_51b0b4855ce19ff50d54548f43724412.html", "dir_51b0b4855ce19ff50d54548f43724412" ],
    [ "weightmodels", "dir_9d0f1dcd39608caeed27927b7f549470.html", "dir_9d0f1dcd39608caeed27927b7f549470" ],
    [ "bwbtype.cpp", "bwbtype_8cpp.html", "bwbtype_8cpp" ],
    [ "bwbtype.h", "bwbtype_8h.html", [
      [ "BWBType", "class_stardust_plus_1_1_b_w_b_type.html", "class_stardust_plus_1_1_b_w_b_type" ]
    ] ]
];