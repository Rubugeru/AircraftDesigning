var dir_c49d78b68314d716aecf960a549a4b2b =
[
    [ "basicperformance.cpp", "basicperformance_8cpp.html", "basicperformance_8cpp" ],
    [ "basicperformance.h", "basicperformance_8h.html", [
      [ "BasicPerformance", "class_stardust_plus_1_1_basic_performance.html", "class_stardust_plus_1_1_basic_performance" ]
    ] ]
];