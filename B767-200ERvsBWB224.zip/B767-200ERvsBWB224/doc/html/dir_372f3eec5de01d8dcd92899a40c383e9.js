var dir_372f3eec5de01d8dcd92899a40c383e9 =
[
    [ "aeromodels", "dir_f2e25e3d72eb8832ce7e40332c10ce4d.html", "dir_f2e25e3d72eb8832ce7e40332c10ce4d" ],
    [ "weightmodels", "dir_a23961ae4230fd1eee57e43dfc8e7e04.html", "dir_a23961ae4230fd1eee57e43dfc8e7e04" ],
    [ "tubewingtype.cpp", "tubewingtype_8cpp.html", "tubewingtype_8cpp" ],
    [ "tubewingtype.h", "tubewingtype_8h.html", [
      [ "TubeWingType", "class_stardust_plus_1_1_tube_wing_type.html", "class_stardust_plus_1_1_tube_wing_type" ]
    ] ]
];