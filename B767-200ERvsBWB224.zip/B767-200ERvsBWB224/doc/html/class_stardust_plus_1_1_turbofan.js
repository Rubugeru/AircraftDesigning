var class_stardust_plus_1_1_turbofan =
[
    [ "Turbofan", "class_stardust_plus_1_1_turbofan.html#a2589a2d378d42469e9d7a5b6c8b3949b", null ],
    [ "~Turbofan", "class_stardust_plus_1_1_turbofan.html#a0e49ed0747a20ac2e5acea6898efe7c6", null ],
    [ "cj", "class_stardust_plus_1_1_turbofan.html#ad01dbb517013252e6e47c2d29f3888cd", null ],
    [ "getType", "class_stardust_plus_1_1_turbofan.html#ad814a50c609550995db9463513e132a5", null ],
    [ "getValue", "class_stardust_plus_1_1_turbofan.html#a5057c9c725bfa05f195580efbdcd8184", null ],
    [ "is_assignable", "class_stardust_plus_1_1_turbofan.html#adb38d2a9312b7560cb2393bb3f5c0aa3", null ],
    [ "Lp", "class_stardust_plus_1_1_turbofan.html#ab76fb1f440a30e0410ffa1f2a056cb4a", null ],
    [ "reconstruct", "class_stardust_plus_1_1_turbofan.html#a1d63b6b5f073ebe38050214b4dfb7581", null ],
    [ "scale", "class_stardust_plus_1_1_turbofan.html#a115bb4e6b0556c4849e1360e54d119a8", null ],
    [ "setValue", "class_stardust_plus_1_1_turbofan.html#a66d143d359906a6602de0f036b77646a", null ],
    [ "assignable", "class_stardust_plus_1_1_turbofan.html#aa353ae83f4be6716a59259f08a832163", null ]
];