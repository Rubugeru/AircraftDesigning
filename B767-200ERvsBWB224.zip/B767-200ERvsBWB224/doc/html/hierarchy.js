var hierarchy =
[
    [ "StardustPlus::Atmosphere", "class_stardust_plus_1_1_atmosphere.html", null ],
    [ "StardustPlus::Component", "class_stardust_plus_1_1_component.html", [
      [ "StardustPlus::LiftingBody", "class_stardust_plus_1_1_lifting_body.html", null ],
      [ "StardustPlus::LiftSurface", "class_stardust_plus_1_1_lift_surface.html", null ],
      [ "StardustPlus::TubeFuselage", "class_stardust_plus_1_1_tube_fuselage.html", null ],
      [ "StardustPlus::Turbofan", "class_stardust_plus_1_1_turbofan.html", null ]
    ] ],
    [ "StardustPlus::EstimationModule", "class_stardust_plus_1_1_estimation_module.html", [
      [ "StardustPlus::AerodynamicsModule", "class_stardust_plus_1_1_aerodynamics_module.html", [
        [ "StardustPlus::RaymerTransonic", "class_stardust_plus_1_1_raymer_transonic.html", null ],
        [ "StardustPlus::TransonicBWB", "class_stardust_plus_1_1_transonic_b_w_b.html", null ]
      ] ],
      [ "StardustPlus::BasicPerformance", "class_stardust_plus_1_1_basic_performance.html", null ],
      [ "StardustPlus::MissionModule", "class_stardust_plus_1_1_mission_module.html", [
        [ "StardustPlus::BasicJet", "class_stardust_plus_1_1_basic_jet.html", null ]
      ] ],
      [ "StardustPlus::WeightModule", "class_stardust_plus_1_1_weight_module.html", [
        [ "StardustPlus::BradleyBWB", "class_stardust_plus_1_1_bradley_b_w_b.html", null ],
        [ "StardustPlus::RinoieTransport", "class_stardust_plus_1_1_rinoie_transport.html", null ]
      ] ]
    ] ],
    [ "StardustPlus::GeometrySet", "class_stardust_plus_1_1_geometry_set.html", [
      [ "StardustPlus::BWBType", "class_stardust_plus_1_1_b_w_b_type.html", null ],
      [ "StardustPlus::TubeWingType", "class_stardust_plus_1_1_tube_wing_type.html", null ]
    ] ],
    [ "StardustPlus::Requirements", "class_stardust_plus_1_1_requirements.html", null ]
];