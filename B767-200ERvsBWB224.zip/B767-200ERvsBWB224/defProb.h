#include <Problem.h>
#include <Solution.h>
#include <RealSolutionType.h>

#include <iostream>
#include <cmath>
#define pi (2.0 * acos(0.0))





#include <components/turbofan.h>
// core headers
#include <core/global/requirements.h>
#include <core/global/atmosphere.h>
// bwb headers
#include <presets/concepts/bwb/bwbtype.h>
#include <presets/concepts/bwb/aeromodels/transonicbwb.h>
#include <presets/concepts/bwb/weightmodels/bradleybwb.h>
// common headers
#include <presets/missionmodels/basicjet.h>
#include <presets/performancemodels/basicperformance.h>
#include <iostream>
#include <cmath>
#define fts_to_kt 0.5924838
using namespace StardustPlus;



Requirements *B767_200ER() {  //requirements.cpp l.15 requirements.h l.13 decide specific requirements
    Atmosphere *atm = new Atmosphere;
    map<string, double> reqs;
    reqs["h_cr"] = 35000.0;
    reqs["h_ceil"] = 41000.0;
    reqs["R_cr"] = 6545.0;
    reqs["V_cr"] = atm->a(reqs["h_cr"]) * 0.80 * fts_to_kt;
    reqs["M_cr"] = 0.80;
    reqs["h_ltr"] = 1500;
    reqs["E_ltr"] = 0.75;
    reqs["M_ltr"] = 0.4;
    reqs["h_div"] = 10000.0;
    reqs["R_div"] = 200.0;
    reqs["M_div"] = 0.75;
    reqs["V_div"] = atm->a(reqs["h_div"]) * 0.75 * fts_to_kt;
    reqs["V_d"] = 400.0 / fts_to_kt;
    reqs["N_crew"] = 10;
    reqs["N_pax"] = 224;
    reqs["W_PL"] = 220.0 * reqs["N_pax"];
    reqs["WL_max"] = 0.759;
    return new Requirements(reqs);
}
void BWBType::init() {
    moduleMap["Aerodynamics"] = new TransonicBWB(this);
    moduleMap["Mission"] = new BasicJet(this);
    moduleMap["Weight"] = new BradleyBWB(this);
    static_cast<BradleyBWB *>(moduleMap["Weight"])->init();
    moduleMap["Performance"] = new BasicPerformance(this);
}

void BWBType::saveData(string filename) { }
void BWBType::saveData(string filename, bool append) { }









class CSIP : public Problem {
public:
    CSIP();
    ~CSIP();
    void evaluate(Solution *solution);
    void evaluateConstraints(Solution *solution);
};

CSIP::CSIP() {
    /* 基本情報の設定 */
    numberOfVariables_ = 10; // 設計変数の数
    numberOfObjectives_ = 2; // 目的関数の数
    numberOfConstraints_ = 12; // 制約条件の数
    problemName_ = "CSIP"; // 問題名の設定

    /* メモリ割り当て */
    lowerLimit_ = new double[numberOfVariables_]; // 下限値のメモリ割り当て
    if (lowerLimit_ == NULL) { // 割り当てに成功していることを確認
        cout << "CSIP::CSIP Memory allocation error. [lowerLimit_]";
        exit(-1); // 失敗していたらエラーメッセージを吐いてプログラムを終了
    }
    upperLimit_ = new double[numberOfVariables_]; // 上限値のメモリ割り当て
    if (upperLimit_ == NULL) { // 領域確保に成功していることを確認
        cout << "CSIP::CSIP Memory allocation error. [upperLimit_]";
        exit(-1); // 失敗していたらエラーメッセージを吐いてプログラムを終了
    }

    /* 上下限値の設定 */
    lowerLimit_[0] = 62100 / 2.0 ; upperLimit_[0] = 62100 * 2.0 ;//離陸推力
    lowerLimit_[1] = 3050      ; upperLimit_[1] = 3050 * 5.0;//主翼面積
    lowerLimit_[2] = 4           ; upperLimit_[2] = 11          ;//主翼AR
    lowerLimit_[3] = 10*pi/180.0 ; upperLimit_[3] = 60*pi/180.0 ;//主翼後退角
    lowerLimit_[4] = 155.0 / 2.0; upperLimit_[4] = 155.0 ;//MidBodyの長さ
    lowerLimit_[5] = 0.15        ; upperLimit_[5] = 0.5         ;//主翼のテーパー比
    lowerLimit_[6] = 2.0         ; upperLimit_[6] = 5.999       ;//Bay数(後に切り捨て)
    lowerLimit_[7] = 2.0         ; upperLimit_[7] = 6.999       ;//貨物列数
    lowerLimit_[8] = 0.0         ; upperLimit_[8] = 0.999       ;//CargoType
    lowerLimit_[9] = 0.0       ; upperLimit_[9] = 10.0       ;//h_margin
    
    
    /* 実数コーディングの指定 */
    solutionType_ = new RealSolutionType(this);
}

CSIP::~CSIP() {
    delete [] lowerLimit_;
    delete [] upperLimit_;
    delete solutionType_;
}

void CSIP::evaluate(Solution *solution) {
    /* 設計変数の値を読み出す　*/
    Variable **variables = solution->getDecisionVariables(); // 必要：但し、様々なコーディング様式に対応するために設計変数は数値ではなくVariableという型で格納されており、そのまま実数値として用いることはできない
    double d[10]; // 不要：目的関数値を計算するときにその都度getValue()で値を読み出してもよい
    for (int i = 0; i < this->numberOfVariables_; i++) { d[i] = variables[i]->getValue(); }

    BWBType *test = new BWBType("B767Type");
    auto eng = static_cast<Turbofan *>(test->getComponent("Engine"));
    double SF = d[0] / test->getComponent("Engine" )->getValue("T_to");//Scale Factor
    eng->scale(SF);//エンジンとナセルの値を書き換え
    test->getComponent("Wing"   )->setValue("S"    ,d[1]);   //主翼面積
    test->getComponent("Wing"   )->setValue("AR"   ,d[2]);   //主翼スパン
    test->getComponent("Wing"   )->setValue("sweep",d[3]);   //主翼後退角
    test->getComponent("MidBody")->setValue("l"    ,d[4]);   //胴体翼長さ
    test->getComponent("Wing"   )->setValue("taper",d[5]);   //主翼テーパー比
    int n_bay = (int)d[6];                                   //設計変数[6]をint型へと切り捨ててn_bay(Bayの数)に格納
    test->getComponent("MidBody")->setValue("n_bay" ,n_bay); //Bayの数を設定
    if ((int)d[8] == 0) {//UnderCargoの場合
        test->getComponent("MidBody")->setValue("h_root", 14.75 + d[9]);
        test->getComponent("MidBody")->setValue("h_mid", 14.75 + d[9]);
        test->getComponent("MidBody")->setValue("h_tip", 8.25 + d[9]);
        int n_cargorow = ((int)(d[7]/2.0))*2;
        test->getComponent("MidBody")->setValue("n_undercargo", n_cargorow);
    }
    if ((int)d[8] == 1) {//SideCargoの場合
        test->getComponent("MidBody")->setValue("h_root", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_mid", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_tip", 6.5 + d[9]);
        int n_cargorow = ((int)(d[7]/2.0))*2;
        test->getComponent("MidBody")->setValue("n_sidecargo", n_cargorow);
    }
    if ((int)d[8] == 2) {//RearCargoの場合
        test->getComponent("MidBody")->setValue("h_root", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_mid", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_tip", 8.25 + d[9]);
        int n_cargorow = (int)d[7];
        test->getComponent("MidBody")->setValue("n_rearcargo", n_cargorow);
    }
    test->reconstruct();//S_expとかS_wetとかtaper_body(連続性)とかを定める
    test->setRequirements(B767_200ER());
    test->init();    //ポインタ変数testに格納されたBWBTypeオブジェクトに対してinit()してください。

    /* 目的関数値を計算する */
    auto Mission = static_cast<BasicJet *>(test->getModule("Mission"));
    double f1 = 1/(Mission->getLD_cr());
    auto Weight = static_cast<BradleyBWB *>(test->getModule("Weight"));
    double f2 = Weight->getWeight("TakeOff");
    // jMetalは目的関数を最小化することに注意

    /* 目的関数値を解に紐付けする */
    solution -> setObjective(0, f1);
    solution -> setObjective(1, f2); // コンストラクタでは目的関数を2つとしていたが、3つ目の目的関数値をこの次に書いてもエラーにはならず、意味のない動作をするだけなので注意
}

void CSIP::evaluateConstraints(Solution *solution) {
    int number = 0; // 違反した制約条件の数
    double total = 0.0; // ペナルティ

    /* 設計変数の値を読み出す */
    double d[11];
    Variable **variables = solution->getDecisionVariables();
    for (int i = 0; i < this->numberOfVariables_; i++) { d[i] = variables[i]->getValue(); }

    BWBType *test = new BWBType("B767Type");
    auto eng = static_cast<Turbofan *>(test->getComponent("Engine"));
    double SF = d[0] / test->getComponent("Engine" )->getValue("T_to");//Scale Factor
    eng->scale(SF);//エンジンとナセルの値を書き換え
    test->getComponent("Wing"   )->setValue("S"    ,d[1]);   //主翼面積
    test->getComponent("Wing"   )->setValue("AR"   ,d[2]);   //主翼スパン
    test->getComponent("Wing"   )->setValue("sweep",d[3]);   //主翼後退角
    test->getComponent("MidBody")->setValue("l"    ,d[4]);   //胴体翼長さ
    test->getComponent("Wing"   )->setValue("taper",d[5]);   //主翼テーパー比
    int n_bay = (int)d[6];                                   //設計変数[6]をint型へと切り捨ててn_bay(Bayの数)に格納
    test->getComponent("MidBody")->setValue("n_bay" ,n_bay); //Bayの数を設定
    if ((int)d[8] == 0) {//UnderCargoの場合
        test->getComponent("MidBody")->setValue("h_root", 14.75 + d[9]);
        test->getComponent("MidBody")->setValue("h_mid", 14.75 + d[9]);
        test->getComponent("MidBody")->setValue("h_tip", 8.25 + d[9]);
        int n_cargorow = ((int)(d[7]/2.0))*2;
        test->getComponent("MidBody")->setValue("n_undercargo", n_cargorow);
    }
    if ((int)d[8] == 1) {//SideCargoの場合
        test->getComponent("MidBody")->setValue("h_root", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_mid", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_tip", 6.5 + d[9]);
        int n_cargorow = ((int)(d[7]/2.0))*2;
        test->getComponent("MidBody")->setValue("n_sidecargo", n_cargorow);
    }
    if ((int)d[8] == 2) {//RearCargoの場合
        test->getComponent("MidBody")->setValue("h_root", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_mid", 8.25 + d[9]);
        test->getComponent("MidBody")->setValue("h_tip", 8.25 + d[9]);
        int n_cargorow = (int)d[7];
        test->getComponent("MidBody")->setValue("n_rearcargo", n_cargorow);
    }

    test->reconstruct();//S_expとかS_wetとかtaper_body(連続性)とかを定める


    test->setRequirements(B767_200ER());
    test->init();    //ポインタ変数testに格納されたBWBTypeオブジェクトに対してinit()してください。

    /* 制約条件になる値を計算する */
    double g[12];
    auto Performance = static_cast<BasicPerformance *>(test->getModule("Performance"));
    g[0] = 8150-(Performance->TOFL(0.0)); //TOFLが7500ft以下
    g[1] = 5100-(Performance->LFL(0.0)); //LFLが5400ft以下
    g[2] = (Performance->SSC() * 100.0)-2.4;//SSCが2.4以上
    g[3] = (Performance->ICAC())-300;//ICACが300以上
    g[4] = test->getComponent("MidBody")->getValue("L_total") - 130;//客室が十分な長さかどうかを評価(統計式より)(LandingGear収納スペースは考慮していない)
    g[5] = test->getComponent("MidBody")->getValue("L_cargo_total") - 63.98;//貨物室が十分な長さかどうかを評価(75ftは必要と思われる長さ)
    g[6] = test->getComponent("MidBody")->getValue("l_sweep") * 180 / pi - 30;//前縁後退角の制約条件
    g[7] = 60 - test->getComponent("MidBody")->getValue("l_sweep") * 180 / pi;
    g[8] = 270 - test->getComponent("Wing")->getValue("b");//Span
    auto Weight = static_cast<BradleyBWB *>(test->getModule("Weight"));
    g[9] = (test->getComponent("Wing")->getValue("all_x_ac") - max(Weight->getWeight("CG_FW"), Weight->getWeight("CG_BW")))/(test->getComponent("Wing")->getValue("all_mac")) - 0.05;//静安定余裕
    g[10] = test->getComponent("MidBody")->getValue("tc_average") - 0.15;
    g[11] = 0.17 - test->getComponent("MidBody")->getValue("tc_average");

    
    
    /* 制約条件違反を探知する */
    for (int j = 0; j < this->numberOfConstraints_; j++) {
        if (g[j] < 0.0) {
            number++;
            total -= 20.0; // ペナルティの大きさを制約条件や違反の度合いによって変えることもできる。必ず負の値になるように。
        }
    }
    
    /* 制約条件違反を解に紐付ける */
    solution -> setOverallConstraintViolation(total); // ペナルティの合計
    solution -> setNumberOfViolatedConstraints(number); // 違反した制約条件の数
    // 目的関数と同様、設定する違反数が制約条件の数を超えていてもエラーにはならず、意味のない動作をするだけなので注意
}



