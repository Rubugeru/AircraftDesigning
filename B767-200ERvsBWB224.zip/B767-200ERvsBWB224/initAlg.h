#include <Problem.h>
#include <Solution.h>
#include <Algorithm.h>

#include <SBXCrossover.h>
#include <PolynomialMutation.h>
#include <BinaryTournament2.h>

#include <QualityIndicator.h>

#include <NSGAII.h>

#include <iostream>
#include <time.h>
using namespace std;

SolutionSet *run_nsgaii(Problem *problem, Algorithm *algorithm) { // 解く問題と初期化するアルゴリズムへのポインタを受け取る
    Operator *crossover; // 交叉
    Operator *mutation; // 突然変異
    Operator *selection; // 選択

    if (problem == NULL) { // NULLチェック
        cout << "init_nsgaii: Sequence failed. nullptr assigned as problem. Terminating." << endl;
        exit(-1);
    }
    /* NSGAIIオブジェクトの初期化 */
    else algorithm = new NSGAII(problem); // 引数として与えられたproblemを解くNSGAIIオブジェクトを作成し、引数として与えられたポインタalgorithmから参照できるようにする
    
    /* 個体数と世代数 */
    int populationSize = 100; // 個体数
    int maxEvaluationSize = 10000; // 関数評価回数(=個体数と世代数の積。ここでは250世代に相当する)
    algorithm->setInputParameter("populationSize", &populationSize);
    algorithm->setInputParameter("maxEvaluations", &maxEvaluationSize);

    /* 遺伝的オペレータの初期化 */
    map<string, void *> parameters; // 文字列をキーに、任意型へのポインタをコンテンツに持つmap

    double crossoverProbability = 0.9; // 交叉確率
    double crossoverDistributionIndex = 20.0; // 実数コーディングで必要な設定値。多分変えないほうがいい
    parameters["probability"] = &crossoverProbability; // mapにはポインタを登録する
    parameters["distributionIndex"] = &crossoverDistributionIndex;
    crossover = new SBXCrossover(parameters); // 交叉オペレータを初期化
    parameters.clear(); // mapをリセットする

    double mutationProbability = 1.0 / problem->getNumberOfVariables(); // 突然変異確率
    double mutationDistributionIndex = 20.0; // 実数コーディングで必要な設定値。多分変えないほうがいい
    parameters["probability"] = &mutationProbability;
    parameters["distributionIndex"] = &mutationDistributionIndex;
    mutation = new PolynomialMutation(parameters); // 突然変異オペレータを初期化
    parameters.clear(); // mapをリセットする
    
    selection = new BinaryTournament2(parameters); // 選択オペレータを初期化：特に設定するパラメータはない

    /* アルゴリズムに遺伝的オペレータを登録する */
    algorithm->addOperator("crossover", crossover);
    algorithm->addOperator("mutation", mutation);
    algorithm->addOperator("selection", selection);
    
    QualityIndicator * indicators = new QualityIndicator(problem, "FUN"); // modified
    algorithm->setInputParameter("indicators", indicators); // modified
    
    /* アルゴリズムを実行する */
    SolutionSet * population = static_cast<NSGAII *>(algorithm)->execute("./LOG"); // modified
    
    return population; // 最終世代の非劣解集合を返す
}
